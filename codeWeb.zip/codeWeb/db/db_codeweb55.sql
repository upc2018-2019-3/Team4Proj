/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50527
 Source Host           : localhost:3306
 Source Schema         : 00_db_codeweb

 Target Server Type    : MySQL
 Target Server Version : 50527
 File Encoding         : 65001

 Date: 13/07/2019 20:43:37
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admininfo
-- ----------------------------
DROP TABLE IF EXISTS `admininfo`;
CREATE TABLE `admininfo`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `adminpassword` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of admininfo
-- ----------------------------
INSERT INTO `admininfo` VALUES (1, 'admin', '123456');

-- ----------------------------
-- Table structure for huodong
-- ----------------------------
DROP TABLE IF EXISTS `huodong`;
CREATE TABLE `huodong`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '活动id',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '活动标题',
  `content` varchar(5000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '活动内容',
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '活动地点',
  `daytime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '活动时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of huodong
-- ----------------------------
INSERT INTO `huodong` VALUES (5, '第二届“绽放杯”5G应用征集大赛暨智媒技术专题赛校园行活动走进大学', '随着5G技术在国内正式商用，各行各业对5G技术的关注度逐渐攀升。“4G改变生活，5G改变社会。”5G技术会携哪些应用方式走进日常生活，在我们身边产生改变？来自中国信息通信研究院、华为技术有限公司的专家走进南华大学，在第二届“绽放杯”5G应用征集大赛暨智媒技术专题赛校园行活动中，为青年师生答疑解惑。此次活动由光明日报社、中国信息通信研究院共同创办的“互联网+”智媒技术创新中心主办，我们大学承办。', 'xxx教学楼123教师', '2019-07-20');
INSERT INTO `huodong` VALUES (6, '11第二届“绽放杯”5G应用征集大赛暨智媒技术专题赛校园行活动走进大学', '随着5G技术在国内正式商用，各行各业对5G技术的关注度逐渐攀升。“4G改变生活，5G改变社会。”5G技术会携哪些应用方式走进日常生活，在我们身边产生改变？来自中国信息通信研究院、华为技术有限公司的专家走进南华大学，在第二届“绽放杯”5G应用征集大赛暨智媒技术专题赛校园行活动中，为青年师生答疑解惑。此次活动由光明日报社、中国信息通信研究院共同创办的“互联网+”智媒技术创新中心主办，我们大学承办。', 'xxx教学楼123教师', '2019-07-20');
INSERT INTO `huodong` VALUES (7, '222第二届“绽放杯”5G应用征集大赛暨智媒技术专题赛校园行活动走进大学', '随着5G技术在国内正式商用，各行各业对5G技术的关注度逐渐攀升。“4G改变生活，5G改变社会。”5G技术会携哪些应用方式走进日常生活，在我们身边产生改变？来自中国信息通信研究院、华为技术有限公司的专家走进南华大学，在第二届“绽放杯”5G应用征集大赛暨智媒技术专题赛校园行活动中，为青年师生答疑解惑。此次活动由光明日报社、中国信息通信研究院共同创办的“互联网+”智媒技术创新中心主办，我们大学承办。', 'xxx教学楼123教师', '2019-07-20');
INSERT INTO `huodong` VALUES (8, '33第二届“绽放杯”5G应用征集大赛暨智媒技术专题赛校园行活动走进大学', '随着5G技术在国内正式商用，各行各业对5G技术的关注度逐渐攀升。“4G改变生活，5G改变社会。”5G技术会携哪些应用方式走进日常生活，在我们身边产生改变？来自中国信息通信研究院、华为技术有限公司的专家走进南华大学，在第二届“绽放杯”5G应用征集大赛暨智媒技术专题赛校园行活动中，为青年师生答疑解惑。此次活动由光明日报社、中国信息通信研究院共同创办的“互联网+”智媒技术创新中心主办，我们大学承办。', 'xxx教学楼123教师', '2019-07-20');
INSERT INTO `huodong` VALUES (10, '学生互联网+活动', '学生互联网+活动学生互联网+活动学生互联网+活动学生互联网+活动学生互联网+活动学生互联网+活动学生互联网+活动学生互联网+活动学生互联网+活动学生互联网+活动学生互联网+活动', '888号教学楼', '2019-07-28');

-- ----------------------------
-- Table structure for huodongscore
-- ----------------------------
DROP TABLE IF EXISTS `huodongscore`;
CREATE TABLE `huodongscore`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `huodongid` int(11) NULL DEFAULT NULL COMMENT '活动ID',
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '评分用户',
  `role` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '评分角色',
  `score` int(11) NULL DEFAULT NULL COMMENT '评分分值',
  `createtime` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of huodongscore
-- ----------------------------
INSERT INTO `huodongscore` VALUES (1, 6, 'tianming', '学生', 66, '2019-07-13 17:18:52');
INSERT INTO `huodongscore` VALUES (2, 8, 'tianming', '学生', 100, '2019-07-13 17:18:59');
INSERT INTO `huodongscore` VALUES (3, 5, 'tianming', '老师', 100, '2019-07-13 17:24:03');
INSERT INTO `huodongscore` VALUES (4, 5, 'tea123', '学生', 90, '2019-07-13 17:24:07');
INSERT INTO `huodongscore` VALUES (5, 10, 'tianming', '学生', 100, '2019-07-13 18:02:59');
INSERT INTO `huodongscore` VALUES (6, 10, 'tea123', '教师', 80, '2019-07-13 18:04:55');
INSERT INTO `huodongscore` VALUES (7, 10, 'king', '学生', 60, '2019-07-13 18:14:02');
INSERT INTO `huodongscore` VALUES (8, 10, 'xiaoming', '学生', 60, '2019-07-13 20:37:28');

-- ----------------------------
-- Table structure for userinfo
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '学号',
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '性别',
  `role` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '角色',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE,
  UNIQUE INDEX `username_2`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
INSERT INTO `userinfo` VALUES (1, 'tianming', '123456', '18312312301', 'tianming@qq.com', '男', '学生');
INSERT INTO `userinfo` VALUES (2, 'tea123', '123456', '18314463789', 'test@qq.com', '女', '教师');
INSERT INTO `userinfo` VALUES (3, 'king', '123', '13156860407', '222@qq.com', '男', '学生');
INSERT INTO `userinfo` VALUES (4, 'xiaoming', '123456', '18314463787', '1234@qq.com', '女', '学生');

SET FOREIGN_KEY_CHECKS = 1;
