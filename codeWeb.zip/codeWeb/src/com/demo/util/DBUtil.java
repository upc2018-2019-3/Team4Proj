package com.demo.util;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 数据库连接工具类
 */
public class DBUtil {
    private static String driver = "com.mysql.jdbc.Driver";// 驱动类名
    private static String username = "root";// 数据库用户名
    private static String password = "tianming";// 数据库密码
    private static String url = "jdbc:mysql://localhost/00_db_codeweb?characterEncoding=utf8";// 连接地址

    public static Connection getConn() {
        Connection conn = null;
        try {
            Class.forName(driver); // 加载驱动
            conn = DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    /**
     * jdbc执行executeUpdate语句封装方法
     *
     * @param sql    执行sql 语句
     * @param params 参数列表
     * @return
     */
    public static int executeUpdate(String sql, Object[] params) {
        try {
            Connection connection = getConn();
            PreparedStatement ps = connection.prepareStatement(sql);
            if (params != null && params.length != 0) {
                for (int i = 0; i < params.length; i++) {
                    ps.setObject(i + 1, params[i]);
                }
            }
            int row = ps.executeUpdate();
            ps.close();
            connection.close();
            return row;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * jdbc工具类 将查询结果转为map集合
     *
     * @param set
     * @return
     * @throws SQLException
     */
    public static Map<String, Object> handle(ResultSet set) throws SQLException {
        Map<String, Object> map = new HashMap<String, Object>();
        ResultSetMetaData rsmd = set.getMetaData();
        int count = rsmd.getColumnCount();


        for (int i = 0; i < count; i++) {
            map.put(rsmd.getColumnName(i + 1), set.getObject(i + 1));
        }
        return map;
    }


    public static void main(String[] args) {
        Connection conn = DBUtil.getConn();
        System.out.println("conn = " + conn);
    }

}
