package com.demo.entity;

import java.util.Date;

public class Huodong {
    private Integer id;    //活动id
    private String title;    //活动标题
    private String content;    //活动内容
    private String address;    //活动地点
    private String daytime;    //活动时间
    private double score; //活动得分

    public Huodong() {

    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setDaytime(String daytime) {
        this.daytime = daytime;
    }

    public String getDaytime() {
        return daytime;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return "Huodong{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", address='" + address + '\'' +
                ", daytime='" + daytime + '\'' +
                ", score=" + score +
                '}';
    }
}

