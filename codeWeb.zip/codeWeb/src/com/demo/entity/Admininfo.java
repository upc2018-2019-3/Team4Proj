package com.demo.entity;

import java.util.Date;

public class Admininfo {
    private Integer id;
    private String adminname;
    private String adminpassword;

    public Admininfo() {

    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setAdminname(String adminname) {
        this.adminname = adminname;
    }

    public String getAdminname() {
        return adminname;
    }

    public void setAdminpassword(String adminpassword) {
        this.adminpassword = adminpassword;
    }

    public String getAdminpassword() {
        return adminpassword;
    }

    @Override
    public String toString() {
        return " Admininfo [id=" + id + " , adminname=" + adminname + " , adminpassword=" + adminpassword + "]";
    }

}

