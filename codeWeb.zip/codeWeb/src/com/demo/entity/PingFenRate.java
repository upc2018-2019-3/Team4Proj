package com.demo.entity;

public class PingFenRate {

    public static double stuRate = 0.3; //学生评分比例
    public static double teaRate = 0.7; //教师评分比例

}
