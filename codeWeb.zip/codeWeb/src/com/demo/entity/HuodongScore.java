package com.demo.entity;

import java.util.Date;

public class HuodongScore {
    private Integer id;    //id
    private Integer huodongid;    //活动ID
    private String username;    //评分用户
    private String role;    //评分角色
    private Integer score;    //评分分值
    private String createtime;    //创建时间

    public HuodongScore() {

    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setHuodongid(Integer huodongid) {
        this.huodongid = huodongid;
    }

    public Integer getHuodongid() {
        return huodongid;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getRole() {
        return role;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getScore() {
        return score;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getCreatetime() {
        return createtime;
    }

    @Override
    public String toString() {
        return " HuodongScore [id=" + id + " , huodongid=" + huodongid + " , username=" + username + " , role=" + role + " , score=" + score + " , createtime=" + createtime + "]";
    }

}

