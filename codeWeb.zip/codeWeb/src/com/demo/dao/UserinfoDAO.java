package com.demo.dao;

import com.demo.entity.Userinfo;
import com.demo.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class UserinfoDAO {
    //插入方法
    public int insert(Userinfo obj) {
        String sql = "INSERT INTO  userinfo(id,username,password,phone,email,sex,role) VALUES (?,?,?,?,?,?,?)";
        Object[] objects = {obj.getId(), obj.getUsername(), obj.getPassword(), obj.getPhone(), obj.getEmail(), obj.getSex(), obj.getRole()};
        int row = DBUtil.executeUpdate(sql, objects);
        return row;
    }

    //修改方法
    public int update(Userinfo obj) {
        String sql = "UPDATE  userinfo SET  username=?,password=?,phone=?,email=?,sex=?,role=? WHERE id=? ";
        Object[] objects = {obj.getUsername(), obj.getPassword(), obj.getPhone(), obj.getEmail(), obj.getSex(), obj.getRole(), obj.getId()};
        int row = DBUtil.executeUpdate(sql, objects);
        return row;
    }

    //删除方法
    public int delete(int id) {
        String sql = "DELETE FROM userinfo WHERE id  = ? ";
        Object[] objs = {id};
        return DBUtil.executeUpdate(sql, objs);
    }

    //根据id查询一条记录
    public Userinfo get(int idvalue) {
        Userinfo userinfo = null;
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            String sql = "select * from userinfo where id=" + idvalue;
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String phone = rs.getString("phone");
                String email = rs.getString("email");
                String sex = rs.getString("sex");
                String role = rs.getString("role");
                userinfo = new Userinfo();
                userinfo.setRole(role);
                userinfo.setId(id);
                userinfo.setUsername(username);
                userinfo.setPassword(password);
                userinfo.setPhone(phone);
                userinfo.setEmail(email);
                userinfo.setSex(sex);
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userinfo;
    }

    //根据要求查询数据库中信息
    public List<Userinfo> find(Map map) {
        List<Userinfo> list = new ArrayList<Userinfo>();
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            String sql = "select * from userinfo ";
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String phone = rs.getString("phone");
                String email = rs.getString("email");
                String sex = rs.getString("sex");
                String role = rs.getString("role");
                Userinfo userinfo = new Userinfo();
                userinfo.setRole(role);
                userinfo.setId(id);
                userinfo.setUsername(username);
                userinfo.setPassword(password);
                userinfo.setPhone(phone);
                userinfo.setEmail(email);
                userinfo.setSex(sex);
                list.add(userinfo);
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }


    //执行登录方法
    public Userinfo login(String usernameVar, String passwordVar) {
        Userinfo userinfo = null;
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            String sql = "select * from userinfo where username='" + usernameVar + "' and password='" + passwordVar + "'";
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String phone = rs.getString("phone");
                String email = rs.getString("email");
                String sex = rs.getString("sex");
                String role = rs.getString("role");
                userinfo = new Userinfo();
                userinfo.setRole(role);
                userinfo.setId(id);
                userinfo.setUsername(username);
                userinfo.setPassword(password);
                userinfo.setPhone(phone);
                userinfo.setEmail(email);
                userinfo.setSex(sex);
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userinfo;
    }


}
