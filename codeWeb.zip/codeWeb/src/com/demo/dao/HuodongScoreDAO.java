package com.demo.dao;

import com.demo.entity.HuodongScore;
import com.demo.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HuodongScoreDAO {

    //插入方法
    public int insert(HuodongScore obj) {
        String sql = "INSERT INTO  huodongscore(id,huodongid,username,role,score,createtime) VALUES (?,?,?,?,?,now())";
        Object[] objects = {obj.getId(), obj.getHuodongid(), obj.getUsername(), obj.getRole(), obj.getScore()};
        int row = DBUtil.executeUpdate(sql, objects);
        return row;
    }

    //修改方法
    public int update(HuodongScore obj) {
        String sql = "UPDATE  huodongscore SET  huodongid=?,username=?,role=?,score=?,createtime=now() WHERE id=? ";
        Object[] objects = {obj.getHuodongid(), obj.getUsername(), obj.getRole(), obj.getScore(), obj.getId()};
        int row = DBUtil.executeUpdate(sql, objects);
        return row;
    }

    //删除方法
    public int delete(int id) {
        String sql = "DELETE FROM huodongscore WHERE id  = ?  ";
        Object[] objs = {id};
        return DBUtil.executeUpdate(sql, objs);
    }

    // 根据活动id和角色进行统计分数
    public int countScore(int huodongid, String role) {
        int nums = 0;
        String sql = "select avg(score) as nums from huodongscore where huodongid='" + huodongid + "'  and role='" + role + "' group  by huodongid,role ";
        System.out.println("sql = " + sql);
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                nums = rs.getInt("nums");
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return nums;
    }

    //根据id查询一条记录
    public HuodongScore get(int idvalue) {
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            String sql = "select * from huodongscore where id=" + idvalue;
            System.out.println("sql = " + sql);
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                int huodongid = rs.getInt("huodongid");
                String username = rs.getString("username");
                String role = rs.getString("role");
                int score = rs.getInt("score");
                String createtime = rs.getString("createtime");
                HuodongScore huodongScore = new HuodongScore();
                huodongScore.setId(id);
                huodongScore.setHuodongid(huodongid);
                huodongScore.setUsername(username);
                huodongScore.setRole(role);
                huodongScore.setScore(score);
                huodongScore.setCreatetime(createtime);
                return huodongScore;
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //检查是否参与了评分
    public boolean checkPingfen(int huodongid, String username) {
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            String sql = "select * from huodongscore where huodongid='" + huodongid + "' and username='" + username + "'";
            System.out.println("sql = " + sql);
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                return true;
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    //根据要求查询数据库中信息
    public List<HuodongScore> find(Map map) {
        List<HuodongScore> list = new ArrayList<HuodongScore>();
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            String sql = "select * from huodongscore ";
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                int huodongid = rs.getInt("huodongid");
                String username = rs.getString("username");
                String role = rs.getString("role");
                int score = rs.getInt("score");
                String createtime = rs.getString("createtime");
                HuodongScore huodongScore = new HuodongScore();
                huodongScore.setId(id);
                huodongScore.setHuodongid(huodongid);
                huodongScore.setUsername(username);
                huodongScore.setRole(role);
                huodongScore.setScore(score);
                huodongScore.setCreatetime(createtime);
                list.add(huodongScore);
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }


}
