package com.demo.dao;

import com.demo.entity.Admininfo;
import com.demo.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AdmininfoDAO {

    //插入方法
    public int insert(Admininfo obj) {
        String sql = "INSERT INTO  admininfo(id,adminname,adminpassword) VALUES (?,?,?)";
        Object[] objects = {obj.getId(), obj.getAdminname(), obj.getAdminpassword()};
        int row = DBUtil.executeUpdate(sql, objects);
        return row;
    }

    //修改方法
    public int update(Admininfo obj) {
        String sql = "UPDATE  admininfo SET  adminname=?,adminpassword=? WHERE id=?  ";
        Object[] objects = {obj.getAdminname(), obj.getAdminpassword(), obj.getId()};
        int row = DBUtil.executeUpdate(sql, objects);
        return row;
    }

    //删除方法
    public int delete(int id) {
        String sql = "DELETE FROM admininfo WHERE id  = ? ";
        Object[] objs = {id};
        return DBUtil.executeUpdate(sql, objs);
    }

    //根据id查询一条记录
    public Admininfo get(int idvalue) {
        Admininfo admininfo = null;
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            String sql = "select * from admininfo where id=" + idvalue;
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String adminname = rs.getString("adminname");
                String adminpassword = rs.getString("adminpassword");
                admininfo = new Admininfo();
                admininfo.setId(id);
                admininfo.setAdminname(adminname);
                admininfo.setAdminpassword(adminpassword);
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return admininfo;
    }

    //根据要求查询数据库中信息
    public List<Admininfo> find(Map map) {
        List<Admininfo> list = new ArrayList<Admininfo>();
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            String sql = "select * from admininfo ";
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String adminname = rs.getString("adminname");
                String adminpassword = rs.getString("adminpassword");
                Admininfo admininfo = new Admininfo();
                admininfo.setId(id);
                admininfo.setAdminname(adminname);
                admininfo.setAdminpassword(adminpassword);
                list.add(admininfo);
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public Admininfo login(String name) {
        Admininfo admininfo = null;
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            String sql = "select * from admininfo where adminname='" + name + "'";
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String adminname = rs.getString("adminname");
                String adminpassword = rs.getString("adminpassword");
                admininfo = new Admininfo();
                admininfo.setId(id);
                admininfo.setAdminname(adminname);
                admininfo.setAdminpassword(adminpassword);
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return admininfo;
    }
}
