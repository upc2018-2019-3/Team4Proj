package com.demo.dao;

import com.demo.entity.Huodong;
import com.demo.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HuodongDAO {
    //插入方法
    public int insert(Huodong obj) {
        String sql = "INSERT INTO  huodong(id,title,content,address,daytime) VALUES (?,?,?,?,?)";
        Object[] objects = {obj.getId(), obj.getTitle(), obj.getContent(), obj.getAddress(), obj.getDaytime()};
        int row = DBUtil.executeUpdate(sql, objects);
        return row;
    }

    //修改方法
    public int update(Huodong obj) {
        String sql = "UPDATE  huodong SET  title=?,content=?,address=?,daytime=? WHERE id=? ";
        Object[] objects = {obj.getTitle(), obj.getContent(), obj.getAddress(), obj.getDaytime(), obj.getId()};
        int row = DBUtil.executeUpdate(sql, objects);
        return row;
    }

    //删除方法
    public int delete(int id) {
        String sql = "DELETE FROM huodong WHERE id  = ? ";
        Object[] objs = {id};
        return DBUtil.executeUpdate(sql, objs);
    }

    //根据id查询一条记录
    public Huodong get(int idvalue) {
        Huodong huodong = null;
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            String sql = "select * from huodong where id=" + idvalue;
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String content = rs.getString("content");
                String address = rs.getString("address");
                String daytime = rs.getString("daytime");
                huodong = new Huodong();
                huodong.setId(id);
                huodong.setTitle(title);
                huodong.setContent(content);
                huodong.setAddress(address);
                huodong.setDaytime(daytime);
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return huodong;
    }

    //根据要求查询数据库中信息
    public List<Huodong> find(Map map) {
        List<Huodong> list = new ArrayList<Huodong>();
        try {
            // 获取数据库连接
            Connection conn = DBUtil.getConn();
            String sql = "select * from huodong ";
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String content = rs.getString("content");
                String address = rs.getString("address");
                String daytime = rs.getString("daytime");
                Huodong huodong = new Huodong();
                huodong.setId(id);
                huodong.setTitle(title);
                huodong.setContent(content);
                huodong.setAddress(address);
                huodong.setDaytime(daytime);
                list.add(huodong);
            }
            rs.close();// 释放资源
            pstm.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }


}
