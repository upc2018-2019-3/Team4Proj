package com.demo.servlet;

import com.demo.dao.HuodongDAO;
import com.demo.dao.HuodongScoreDAO;
import com.demo.entity.Huodong;
import com.demo.entity.HuodongScore;
import com.demo.entity.PingFenRate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/huodong")
public class HuodongServlet extends HttpServlet {
    HuodongDAO huodongDAO = new HuodongDAO();
    HuodongScoreDAO scoreDAO = new HuodongScoreDAO();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        if ("list".equals(action)) {
            list(request, response);
        } else if ("insert".equals(action)) {
            insert(request, response);
        } else if ("edit".equals(action)) {
            edit(request, response);
        } else if ("update".equals(action)) {
            update(request, response);
        } else if ("delete".equals(action)) {
            delete(request, response);
        } else if ("huodongScoreList".equals(action)) {
            huodongScoreList(request, response);
        } else if ("huodongScoreResult".equals(action)) {
            huodongScoreResult(request, response);
        } else {
            throw new RuntimeException(request.getRequestURL() + "请求路径不存在");
        }


    }

    private void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String address = request.getParameter("address");
        String daytime = request.getParameter("daytime");
        Huodong huodong = new Huodong();
        huodong.setTitle(title);
        huodong.setContent(content);
        huodong.setAddress(address);
        huodong.setDaytime(daytime);
        huodongDAO.insert(huodong);
        System.out.println("huodong = " + huodong);
        response.sendRedirect("huodong?action=list");
    }

    private void edit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        Huodong huodong = huodongDAO.get(Integer.parseInt(id));
        request.setAttribute("huodong", huodong);
        request.getRequestDispatcher("huodongEdit.jsp").forward(request, response);
    }

    private void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String address = request.getParameter("address");
        String daytime = request.getParameter("daytime");
        Huodong huodong = new Huodong();
        huodong.setId(Integer.valueOf(id));
        huodong.setTitle(title);
        huodong.setContent(content);
        huodong.setAddress(address);
        huodong.setDaytime(daytime);
        huodongDAO.update(huodong);
        response.sendRedirect("huodong?action=list");
    }

    private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        huodongDAO.delete(Integer.parseInt(id));
        response.sendRedirect("huodong?action=list");
    }

    private void huodongScoreResult(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Huodong> huodongList = huodongDAO.find(null);
        for (Huodong huodong : huodongList) {
            int id = huodong.getId();
            int stuScore = scoreDAO.countScore(id, "学生");
            int teaScore = scoreDAO.countScore(id, "教师");
            // 计算 老师 0.7  学生 0.3
            double totalScore = (stuScore * PingFenRate.stuRate) + (teaScore * PingFenRate.teaRate);
            huodong.setScore(totalScore);
        }
        request.setAttribute("scoreList", huodongList);
        request.getRequestDispatcher("scoreList.jsp").forward(request, response);
    }


    private void huodongScoreList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<HuodongScore> huodongScoreList = scoreDAO.find(null);
        request.setAttribute("huodongScoreList", huodongScoreList);
        request.getRequestDispatcher("huodongScoreList.jsp").forward(request, response);
    }

    private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Huodong> huodongList = huodongDAO.find(null);
        request.setAttribute("huodongList", huodongList);
        request.getRequestDispatcher("huodongList.jsp").forward(request, response);
    }
}
