package com.demo.servlet;

import com.demo.dao.AdmininfoDAO;
import com.demo.entity.Admininfo;
import sun.security.util.Password;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/adminLogin")
public class AdminLoginServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置请求编码集  防止接收参数乱码
        request.setCharacterEncoding("utf-8");
        //设置响应格式为网页编码，编码为utf-8  防止输出乱码
        response.setContentType("text/html;charset=UTF-8");

        String name = request.getParameter("name");
        String password = request.getParameter("password");
        String code = request.getParameter("code");

        //获取session
        HttpSession session = request.getSession();
        //获取验证码
        String randCode = session.getAttribute("randCode").toString();

        //判断输入验证码是否相等
        if (!randCode.equals(code)) {
            request.setAttribute("msg", "验证码错误");
            request.getRequestDispatcher("adminLogin.jsp").forward(request, response);
            return;

        }
        //判断用户信息是否正确
        AdmininfoDAO adminDAO = new AdmininfoDAO();
        Admininfo admin = adminDAO.login(name);
        if (null == admin) {//用户名不存在
            request.setAttribute("msg", "用户名不存在");
            request.getRequestDispatcher("adminLogin.jsp").forward(request, response);
            return;
        }
        //判断密码正确
        if (!admin.getAdminpassword().equals(password)) {
            request.setAttribute("errorMsg", "登录密码错误");
            request.getRequestDispatcher("adminLogin.jsp").forward(request, response);
            return;
        }
        //登录成功
        //登陆成功将用户信息放入session中 方便以后调用

        session.setAttribute("loginAdmin", admin);
        response.sendRedirect("adminIndex.jsp");

    }
}
