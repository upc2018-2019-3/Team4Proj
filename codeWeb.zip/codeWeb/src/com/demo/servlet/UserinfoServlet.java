package com.demo.servlet;

import com.demo.dao.UserinfoDAO;
import com.demo.entity.Userinfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/userinfo")
public class UserinfoServlet extends HttpServlet {
    UserinfoDAO userinfoDAO = new UserinfoDAO();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        if ("list".equals(action)) {
            list(request, response);
        } else if ("register".equals(action)) {
            register(request, response);
        } else if ("login".equals(action)) {
            login(request, response);
        } else if ("loginOut".equals(action)) {
            loginOut(request, response);
        }


    }

    private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String code = request.getParameter("code");
        //获取session
        HttpSession session = request.getSession();
        //获取验证码
        String randCode = session.getAttribute("randCode").toString();
        //判断输入验证码是否相等
        if (!randCode.equals(code)) {
            request.setAttribute("errorMsg", "验证码输入错误");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;

        }
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        Userinfo loginUserinfo = userinfoDAO.login(username, password);
        if (null == loginUserinfo) {
            request.setAttribute("errorMsg", "登录用户名或者密码错误");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        } else {
            session.setAttribute("loginUser", loginUserinfo);
            response.sendRedirect("indexServlet?action=list");
        }
    }

    private void register(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String code = request.getParameter("code");
        //获取session
        HttpSession session = request.getSession();
        //获取验证码
        String randCode = session.getAttribute("randCode").toString();
        //判断输入验证码是否相等
        if (!randCode.equals(code)) {
            request.setAttribute("errorMsg", "验证码输入错误");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;

        }
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String sex = request.getParameter("sex");
        String role = request.getParameter("role");
        Userinfo userinfo = new Userinfo();
        userinfo.setUsername(username);
        userinfo.setPassword(password);
        userinfo.setPhone(phone);
        userinfo.setEmail(email);
        userinfo.setSex(sex);
        userinfo.setRole(role);
        userinfoDAO.insert(userinfo);
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }

    private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Userinfo> userinfoList = userinfoDAO.find(null);
        request.setAttribute("userinfoList", userinfoList);
        request.getRequestDispatcher("userinfoList.jsp").forward(request, response);
    }

    private void loginOut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取session
        HttpSession session = request.getSession();
        session.removeAttribute("loginUser");
        response.sendRedirect("login.jsp");
    }
}
