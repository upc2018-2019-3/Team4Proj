package com.demo.servlet;

import com.demo.dao.HuodongDAO;
import com.demo.dao.HuodongScoreDAO;
import com.demo.dao.UserinfoDAO;
import com.demo.entity.Huodong;
import com.demo.entity.HuodongScore;
import com.demo.entity.PingFenRate;
import com.demo.entity.Userinfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/indexServlet")
public class IndexServlet extends HttpServlet {
    UserinfoDAO userinfoDAO = new UserinfoDAO();
    HuodongDAO huodongDAO = new HuodongDAO();
    HuodongScoreDAO scoreDAO = new HuodongScoreDAO();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        if ("list".equals(action)) {
            list(request, response);
        } else if ("pingfen".equals(action)) {
            pingfen(request, response);
        } else if ("pingfenSubmit".equals(action)) {
            pingfenSubmit(request, response);
        } else {
            list(request, response);
        }


    }


    private void pingfenSubmit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        String huodongid = request.getParameter("huodongid");
        String username = request.getParameter("username");
        String role = request.getParameter("role");
        String score = request.getParameter("score");
        int hid = Integer.valueOf(huodongid);
        if (scoreDAO.checkPingfen(hid, username)) {
            request.setAttribute("errorMsg", "您已经参与过评分");
            request.setAttribute("jumpUrl", "indexServlet?action=pingfen&id=" + hid);
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        }
        HuodongScore huodongScore = new HuodongScore();
        huodongScore.setHuodongid(Integer.valueOf(huodongid));
        huodongScore.setUsername(username);
        huodongScore.setRole(role);
        huodongScore.setScore(Integer.valueOf(score));

        scoreDAO.insert(huodongScore);
        list(request, response);
    }

    private void pingfen(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ids = request.getParameter("id");
        int id = Integer.parseInt(ids);
        Huodong huodong = huodongDAO.get(id);

        HttpSession session = request.getSession();
        Userinfo loginUser = (Userinfo) session.getAttribute("loginUser");
        int stuScore = scoreDAO.countScore(id, "学生");
        int teaScore = scoreDAO.countScore(id, "教师");
        System.out.println("teaScore = " + teaScore);
        System.out.println("stuScore = " + stuScore);
        // 计算 老师 0.7  学生 0.3
        double totalScore = (stuScore * PingFenRate.stuRate) + (teaScore * PingFenRate.teaRate);
        request.setAttribute("huodong", huodong);
        request.setAttribute("totalScore", totalScore);
        request.getRequestDispatcher("pingfen.jsp").forward(request, response);
    }

    private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Huodong> huodongList = huodongDAO.find(null);
        request.setAttribute("huodongList", huodongList);
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}
